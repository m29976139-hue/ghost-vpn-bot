import os
import sqlite3
from datetime import datetime

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, ContextTypes, filters
)

BOT_TOKEN = os.getenv("BOT_TOKEN", "PUT_BOT_TOKEN_HERE")
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))

CARD_NUMBER = "6037 7016 0724 8488"
CARD_OWNER = "توحید پارسافر"
VPN_NAME = "Ghost VPN"
PUBLIC_USERNAME = "90_ghost_vpn"

DB = "ghost_vpn.db"

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = db()
    con.execute("""CREATE TABLE IF NOT EXISTS orders(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        username TEXT,
        plan TEXT,
        amount TEXT,
        status TEXT DEFAULT 'pending',
        receipt_file_id TEXT,
        created_at TEXT
    )""")
    con.commit()
    con.close()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("🛒 خرید VPN", callback_data="buy")],
        [InlineKeyboardButton("💳 اطلاعات پرداخت", callback_data="pay")],
        [InlineKeyboardButton("📞 پشتیبانی", callback_data="support")]
    ]
    await update.message.reply_text(
        f"👻 {VPN_NAME}\n\nبه ربات فروش {VPN_NAME} خوش آمدید.",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    keyboard = [
        [InlineKeyboardButton("📦 سفارش‌های در انتظار", callback_data="admin_pending")],
        [InlineKeyboardButton("📊 آمار", callback_data="admin_stats")]
    ]
    await update.message.reply_text(
        "⚙️ پنل مدیریت Ghost VPN",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()

    if q.data == "pay":
        await q.message.reply_text(
            f"💳 اطلاعات پرداخت\n\n"
            f"شماره کارت:\n`{CARD_NUMBER}`\n\n"
            f"به نام: {CARD_OWNER}\n\n"
            "بعد از خرید فیش را لطفاً همین‌جا ارسال کنید.",
            parse_mode="Markdown"
        )

    elif q.data == "buy":
        keyboard = [
            [InlineKeyboardButton("پلن 1 — قیمت را تنظیم کن", callback_data="plan1")],
            [InlineKeyboardButton("پلن 2 — قیمت را تنظیم کن", callback_data="plan2")],
            [InlineKeyboardButton("پلن 3 — قیمت را تنظیم کن", callback_data="plan3")],
            [InlineKeyboardButton("⬅️ بازگشت", callback_data="back")]
        ]
        await q.message.reply_text(
            "🛒 پلن موردنظر را انتخاب کن:",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    elif q.data.startswith("plan"):
        plan = {"plan1": "پلن 1", "plan2": "پلن 2", "plan3": "پلن 3"}[q.data]
        context.user_data["plan"] = plan
        await q.message.reply_text(
            f"✅ {plan} انتخاب شد.\n\n"
            f"💳 شماره کارت: {CARD_NUMBER}\n"
            f"👤 {CARD_OWNER}\n\n"
            "بعد از پرداخت، عکس فیش را همین‌جا ارسال کنید."
        )

    elif q.data == "support":
        await q.message.reply_text(f"📞 پشتیبانی: @{PUBLIC_USERNAME}")

    elif q.data == "back":
        await start_from_callback(q)

    elif q.data == "admin_pending":
        if q.from_user.id != ADMIN_ID:
            return
        con = db()
        rows = con.execute(
            "SELECT * FROM orders WHERE status='pending' ORDER BY id DESC LIMIT 20"
        ).fetchall()
        con.close()

        if not rows:
            await q.message.reply_text("✅ سفارش در انتظار وجود ندارد.")
            return

        text = "📦 سفارش‌های در انتظار:\n\n"
        for r in rows:
            text += (
                f"#{r['id']} | {r['plan']} | {r['username'] or r['user_id']}\n"
                f"وضعیت: {r['status']}\n"
                f"{r['created_at']}\n\n"
            )
        await q.message.reply_text(text)

    elif q.data == "admin_stats":
        if q.from_user.id != ADMIN_ID:
            return
        con = db()
        total = con.execute("SELECT COUNT(*) c FROM orders").fetchone()["c"]
        pending = con.execute(
            "SELECT COUNT(*) c FROM orders WHERE status='pending'"
        ).fetchone()["c"]
        approved = con.execute(
            "SELECT COUNT(*) c FROM orders WHERE status='approved'"
        ).fetchone()["c"]
        con.close()
        await q.message.reply_text(
            f"📊 آمار\n\nکل سفارش‌ها: {total}\n"
            f"در انتظار: {pending}\nتأییدشده: {approved}"
        )

async def start_from_callback(q):
    keyboard = [
        [InlineKeyboardButton("🛒 خرید VPN", callback_data="buy")],
        [InlineKeyboardButton("💳 اطلاعات پرداخت", callback_data="pay")],
        [InlineKeyboardButton("📞 پشتیبانی", callback_data="support")]
    ]
    await q.message.reply_text(
        f"👻 {VPN_NAME}\n\nبه ربات فروش {VPN_NAME} خوش آمدید.",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def receipt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message.photo:
        return

    user = update.effective_user
    plan = context.user_data.get("plan", "نامشخص")
    photo = update.message.photo[-1]

    con = db()
    cur = con.execute(
        """INSERT INTO orders
        (user_id, username, plan, amount, status, receipt_file_id, created_at)
        VALUES (?, ?, ?, ?, 'pending', ?, ?)""",
        (
            user.id,
            user.username,
            plan,
            "تنظیم نشده",
            photo.file_id,
            datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )
    )
    order_id = cur.lastrowid
    con.commit()
    con.close()

    await update.message.reply_text(
        f"✅ فیش شما ثبت شد.\nشماره سفارش: #{order_id}\n"
        "پس از بررسی، نتیجه اعلام می‌شود."
    )

    if ADMIN_ID:
        try:
            await context.bot.send_photo(
                chat_id=ADMIN_ID,
                photo=photo.file_id,
                caption=(
                    f"🧾 فیش جدید — سفارش #{order_id}\n"
                    f"کاربر: @{user.username or 'بدون یوزرنیم'}\n"
                    f"User ID: {user.id}\n"
                    f"پلن: {plan}\n\n"
                    f"برای بررسی از /panel استفاده کن."
                )
            )
        except Exception:
            pass

def main():
    if BOT_TOKEN == "PUT_BOT_TOKEN_HERE":
        raise RuntimeError("BOT_TOKEN را در متغیر محیطی تنظیم کن.")
    if ADMIN_ID == 0:
        raise RuntimeError("ADMIN_ID را در متغیر محیطی تنظیم کن.")

    init_db()
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("panel", panel))
    app.add_handler(CallbackQueryHandler(callback))
    app.add_handler(MessageHandler(filters.PHOTO, receipt))
    app.run_polling()

if __name__ == "__main__":
    main()
